using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using UMOnline.Areas.Identity.Data;
using UMOnline.Models;

namespace UMOnline.Data
{
    public class UMOnlineDbContext : IdentityDbContext<UMOnlineUser>
    {
        public UMOnlineDbContext(DbContextOptions<UMOnlineDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
      // Customize the ASP.NET Identity model and override the defaults if needed.
      // For example, you can rename the ASP.NET Identity table names and more.
      // Add your customizations after calling base.OnModelCreating(builder);


      builder.Entity<Paper>().HasData( new Paper {
        Id=1,
    Title ="Test Research Paper",
   Topic = "Test Research Paper",
       No_of_review =1,
        author_id ="111",
 conference_id=1,
    final ="Waiting",
    status="Reviewed",
    Content ="Text"

  },
  new Paper
  {
    Id = 2,
    Title = "Test Research Paper 2",
    Topic = "Test Research Paper 2",
    No_of_review = 1,
    author_id = "112",
    conference_id = 2,
    final = "Waiting",
    status = "Reviewed",
    Content = "Text"

  },
  new Paper
  {
    Id = 3,
    Title = "Test Research Paper 3",
    Topic = "Test Research Paper 3",
    No_of_review = 1,
    author_id = "113",
    conference_id = 3,
    final = "Waiting",
    status = "Reviewed",
    Content = "Text"

  }


      );


      builder.Entity<Conference>().HasData(


        new Conference
        {

          Id = 1,
          Name = "Conference 1",
          Topic = "Arts and Culture",
          chair_id = "1",
          Paper_deadline = System.DateTime.Now,
           Review_deadline= System.DateTime.Now

        },
         new Conference
         {

           Id = 2,
           Name = "Conference 2",
           Topic = "World History",
           chair_id = "2",
           Paper_deadline = System.DateTime.Now,
           Review_deadline = System.DateTime.Now

         },
          new Conference
          {

            Id = 3,
            Name = "Conference 3",
            Topic = "Trade and Bussiness",
            chair_id = "3",
            Paper_deadline = System.DateTime.Now,
            Review_deadline = System.DateTime.Now

          }


        );


        }

        public DbSet<Paper> Paper { get; set; }
        public DbSet<Review> Review { get; set; }
        public DbSet<Conference> Conference { get; set; }





  }
}
