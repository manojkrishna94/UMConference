﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace UMOnline.Migrations
{
    public partial class seedData3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Conference",
                columns: new[] { "Id", "Name", "Paper_deadline", "Review_deadline", "Topic", "chair_id" },
                values: new object[,]
                {
                    { 1, "Conference 1", new DateTime(2020, 10, 4, 17, 31, 30, 831, DateTimeKind.Local).AddTicks(6215), new DateTime(2020, 10, 4, 17, 31, 30, 832, DateTimeKind.Local).AddTicks(8148), "Arts and Culture", "1" },
                    { 2, "Conference 2", new DateTime(2020, 10, 4, 17, 31, 30, 832, DateTimeKind.Local).AddTicks(9072), new DateTime(2020, 10, 4, 17, 31, 30, 832, DateTimeKind.Local).AddTicks(9086), "World History", "2" },
                    { 3, "Conference 3", new DateTime(2020, 10, 4, 17, 31, 30, 832, DateTimeKind.Local).AddTicks(9095), new DateTime(2020, 10, 4, 17, 31, 30, 832, DateTimeKind.Local).AddTicks(9100), "Trade and Bussiness", "3" }
                });

            migrationBuilder.UpdateData(
                table: "Paper",
                keyColumn: "Id",
                keyValue: 1,
                column: "status",
                value: "Reviewed");

            migrationBuilder.InsertData(
                table: "Paper",
                columns: new[] { "Id", "ConferenceId", "Content", "No_of_review", "Title", "Topic", "author_id", "conference_id", "final", "status" },
                values: new object[,]
                {
                    { 2, null, "Text", 1, "Test Research Paper 2", "Test Research Paper 2", "112", 2, "Waiting", "Reviewed" },
                    { 3, null, "Text", 1, "Test Research Paper 3", "Test Research Paper 3", "113", 3, "Waiting", "Reviewed" }
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Conference",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Conference",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Conference",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Paper",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Paper",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.UpdateData(
                table: "Paper",
                keyColumn: "Id",
                keyValue: 1,
                column: "status",
                value: "Reviewewd");
        }
    }
}
