﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace UMOnline.Migrations
{
    public partial class seedData1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Paper",
                columns: new[] { "Id", "ConferenceId", "Content", "No_of_review", "Title", "Topic", "author_id", "conference_id", "final", "status" },
                values: new object[] { 1, null, "Text", 1, "Test Research Paper", "Test Research Paper", "111", 1, "Waiting", "Reviewewd" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Paper",
                keyColumn: "Id",
                keyValue: 1);
        }
    }
}
