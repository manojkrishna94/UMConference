using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using UMOnline.Areas.Identity.Data;

namespace UMOnline.Models
{
  public class Paper
  {

    public Paper()
    {
    
    }

    public int Id { get; set; }
    public string Title { get; set; }
    public string Topic { get; set; }
    [DisplayName("Number of Reviews")]
    public Nullable<int> No_of_review { get; set; }
    [DisplayName("Author Name/ID")]

    public string author_id { get; set; }
    [DisplayName("conference id")]

    public Nullable<int> conference_id { get; set; }
    public string final { get; set; }
    public string status { get; set; }
    public string Content { get; set; }

    public virtual ICollection<AssignPaper> AssignPapers { get; set; }
    public virtual Conference Conference { get; set; }
    public virtual ICollection<Review> Reviews { get; set; }

  }
}
