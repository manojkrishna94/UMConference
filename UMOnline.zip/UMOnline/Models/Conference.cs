using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UMOnline.Areas.Identity.Data;

namespace UMOnline.Models
{
  public class Conference
  {
    public Conference()
    {
      this.Papers = new HashSet<Paper>();
    }

    public int Id { get; set; }
    public string Name { get; set; }
    public string Topic { get; set; }
    public string chair_id { get; set; }
    public Nullable<System.DateTime> Paper_deadline { get; set; }
    public Nullable<System.DateTime> Review_deadline { get; set; }

    public virtual ICollection<Paper> Papers { get; set; }



  }
}
