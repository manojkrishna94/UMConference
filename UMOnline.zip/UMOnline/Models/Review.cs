using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UMOnline.Areas.Identity.Data;

namespace UMOnline.Models
{
  public class Review
  {

    public int Id { get; set; }
    public string Title { get; set; }
    public string reviewer_id { get; set; }
    public Nullable<System.DateTime> Deadline { get; set; }
    public string Evaluation { get; set; }
    public Nullable<int> Rating { get; set; }
    public Nullable<int> paper_id { get; set; }
    public Nullable<int> assign_id { get; set; }
    public string status { get; set; }

    public virtual Paper Paper { get; set; }
  }
}
