using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UMOnline.Areas.Identity.Data;

namespace UMOnline.Models
{
  public class AssignPaper
  {

    public int PaperId { get; set; }
    public string ReviewerId { get; set; }
    public int Id { get; set; }

    public virtual Paper Paper { get; set; }

  }
}
